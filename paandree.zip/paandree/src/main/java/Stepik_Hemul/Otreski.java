//На числовой прямой даны два отрезка, заданных парами целых чисел:a1 b1, a2 b2
//Напишите программу, которая находит их пересечение.
// Если пересечение - отрезок, необходимо вывести два числа (границы отрезка), если единственная точка -
// единственное число (точку), если пересечения нет - вывести фразу "Пересечения нет" (без кавычек).

package Stepik_Hemul;

import java.util.Scanner;
public class Otreski {
    public static void main(String[] Args){
        Scanner input = new Scanner(System.in);
        int a1 = input.nextInt(), b1 = input.nextInt(), a2 = input.nextInt(), b2 = input.nextInt();

        int a = Math.max(a1, a2);
        int b = Math.min(b1, b2);

        if (a == b) System.out.println(b);
        else if (b < a) System.out.println("Пересечения нет");
        else System.out.println(a + " " + b);

    }
}
