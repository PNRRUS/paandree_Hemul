package Stepik_Hemul;
import java.util.Scanner;

/*
Правила определения високосного года:

год, номер которого кратен 400, — високосный;
остальные годы, номер которых кратен 100, — невисокосные (например, годы 1700, 1800, 1900, 2100, 2200, 2300);
остальные годы, номер которых кратен 4, — високосные.
 */

public class GrigorianCalender {
    public static void main(String[] Args) {

        Scanner input = new Scanner(System.in);
        int day = input.nextInt();
        int month = input.nextInt();
        int year = input.nextInt();

        boolean correctDate = true;

        if (year<=0 || month<=0 || month >= 13 || day <= 0) correctDate = false;
        if (year % 4 != 0 && day == 29 && month == 2) correctDate = false;
        if (year % 100 == 0 && day == 29 && month == 2) correctDate = false;

        switch (month) {
            case 1:
                if (day > 31) correctDate = false;
                break;
            case 2:
                if (day > 29) correctDate = false;
                break;
            case 3:
                if (day > 31) correctDate = false;
                break;
            case 4:
                if (day > 30) correctDate = false;
                break;
            case 5:
                if (day > 31) correctDate = false;
                break;
            case 6:
                if (day > 30) correctDate = false;
                break;
            case 7:
                if (day > 31) correctDate = false;
                break;
            case 8:
                if (day > 31) correctDate = false;
                break;
            case 9:
                if (day > 30) correctDate = false;
                break;
            case 10:
                if (day > 31) correctDate = false;
                break;
            case 11:
                if (day > 30) correctDate = false;
                break;
            case 12:
                if (day > 31) correctDate = false;
                break;
        }
                System.out.print(correctDate);
        System.out.print("8 % 4 " + (8 % 4) + '\n' + "100 % 4 " + (100 % 4));


    }
}
