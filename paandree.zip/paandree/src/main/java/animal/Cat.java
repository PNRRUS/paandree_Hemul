package animal;

public class Cat {

    public static void sayHello()
    {
        System.out.println("Hello! I'm a cat.");
    }

}
