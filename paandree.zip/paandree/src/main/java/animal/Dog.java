package animal;

public class Dog {
    public static void sayHello() {
        System.out.println("Hello! I'm a dog.");
    }
}
