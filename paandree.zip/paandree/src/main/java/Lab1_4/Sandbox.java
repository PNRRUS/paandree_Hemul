package Lab1_4;

import java.util.Scanner;

class Sandbox {
    public static void main(String[] args) {

        String name = "Ivan";
        int age = 25;
        double height = 1.85;
        System.out.println(name);
        System.out.println(age);
        System.out.println(height);
    }
}
