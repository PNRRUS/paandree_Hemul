package Lab1_4;

public class Round {
    public static void main(String[] args) {

        int x = (int) Math.round(Math.random() * 9);
        int y = (int) Math.round(Math.random() * 9);
        System.out.println("x = " + x);
        System.out.println("y = " + y);
        System.out.println(x > y ? "Переменная х больше, чем у" : "Переменная y больше, чем x");

    }
}
