package Lab1_4;

public class Circle {
    int x; // абсцисса центра окружности
    int y; // ордината центра окружности
    double r; // радиус окружности

    // создание окружности по умолчанию
    public Circle () {
        x = 0;
        y = 0;
        r = 1;
    }

    // создание окружности по конкретным данным
    public Circle (int x, int y, double r) {
        this.x = x;
        this.y = y;
        this.r = r;
    }

    // сдвиг окружности
    public void moveCircle(int moveX, int moveY) {
        x += moveX;
        y += moveY;
    }
    // площадь окружности
    public double CircleLength (Circle p) {
        double c = 2 * Math.PI * p.r;
        return c;
    }

}
