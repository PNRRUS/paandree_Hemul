package robot;

public class Terminator {
    public static void sayHello() {
        System.out.println("Hello! I'm a Terminator.");
    }
}
